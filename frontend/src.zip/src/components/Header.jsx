import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { FaListUl } from 'react-icons/fa';
import '../styles/header.css'; // Make sure the path matches your folder

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="header-container">
      <div className="logo">EyeQuest</div>

      <div className="menu-icon" onClick={toggleMenu}>
        <FaListUl />
      </div>

      <nav className={`nav-links ${isMenuOpen ? 'active' : ''}`}>
        <ul>
          <li><Link to="/home">Home</Link></li>
          <li><Link to="/about">About</Link></li>
          <li><Link to="/">Sign In</Link></li>
          <li><Link to="/registerform">Sign Up</Link></li>
        </ul>
      </nav>
    </header>
  );
};

export default Header;
