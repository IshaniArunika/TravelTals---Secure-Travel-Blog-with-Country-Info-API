import React from 'react';
import '../style/AuthForm.css';

const RegisterForm = () => {
  return (
    <div className="form-container">
      <div className="form-card">
        <h1 className="form-title">Sign Up</h1>

        <div className="form-group">
          <label htmlFor="email">Email address</label>
          <input type="email" id="email" className="form-input" placeholder="Enter email" />
        </div>

        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input type="password" id="password" className="form-input" placeholder="Enter password" />
        </div>

        <div className="form-group">
          <label htmlFor="confirm">Confirm Password</label>
          <input type="password" id="confirm" className="form-input" placeholder="Confirm password" />
        </div>

        <button className="submit-button">Register</button>
      </div>
    </div>
  );
};

export default RegisterForm;
