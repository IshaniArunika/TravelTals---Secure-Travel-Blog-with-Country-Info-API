import React from 'react';
import '../style/AuthForm.css';

const LoginForm = () => {
  return (
    <div className="form-container">
      <div className="form-card">
        <h1 className="form-title">Sign In</h1>

        <div className="form-group">
          <label htmlFor="email">Email address</label>
          <input type="email" id="email" className="form-input" placeholder="Enter email" />
        </div>

        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input type="password" id="password" className="form-input" placeholder="Enter password" />
        </div>

        <div className="form-check">
          <input type="checkbox" id="remember" className="form-checkbox" />
          <label htmlFor="remember" className="form-check-label">Remember me</label>
        </div>

        <button className="submit-button">Submit</button>

        <div className="forgot-password-container">
          <a href="#" className="forgot-password-link">Forgot password?</a>
        </div>
      </div>
    </div>
  );
};

export default LoginForm;
