import React, { useState } from 'react';
import LoginForm from './LoginForm';  // or use a relative path
import RegisterForm from './RegisterForm';

const Home = () => {
  const [showLogin, setShowLogin] = useState(true);

  return (
    <div className="home-container">
      <h1>Welcome to EyeQuest 👁️</h1>
      <p>Choose an option to get started:</p>
      
      <div style={{ marginTop: '20px' }}>
        <button onClick={() => setShowLogin(true)}>Login</button>
        <button onClick={() => setShowLogin(false)}>Register</button>
      </div>

      <div style={{ marginTop: '40px' }}>
        {showLogin ? <LoginForm /> : <RegisterForm />}
      </div>
    </div>
  );
};

export default Home;
