const Tokens = require('csrf');
const tokens = new Tokens();

const generateCsrfToken = () => {
    return tokens.create(process.env.CSRF_SECRET);
};

const verifyCsrfToken = (token, secret) => {
    return tokens.verify(secret, token);
};

module.exports = { generateCsrfToken, verifyCsrfToken };
