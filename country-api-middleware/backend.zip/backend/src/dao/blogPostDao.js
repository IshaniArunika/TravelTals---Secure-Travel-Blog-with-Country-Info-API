const db = require('../config/db');

module.exports = {
  createPost: (post, callback) => {
    const sql = `
      INSERT INTO blog_posts (user_id, title, content, country, date_of_visit, image_url)
      VALUES (?, ?, ?, ?, ?, ?)
    `;
    const params = [post.user_id, post.title, post.content, post.country, post.date_of_visit, post.image_url];
    db.run(sql, params, function (err) {
      callback(err, this?.lastID);
    });
  },

  getPostById: (id, callback) => {
    const sql = `SELECT * FROM blog_posts WHERE id = ?`;
    db.get(sql, [id], callback);
  },

  getAllPosts: (callback) => {
    const sql = `SELECT * FROM blog_posts ORDER BY created_at DESC`;
    db.all(sql, [], callback);
  },

  updatePost: (id, post, callback) => {
    const sql = `
      UPDATE blog_posts
      SET title = ?, content = ?, country = ?, date_of_visit = ?, image_url = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `;
    const params = [post.title, post.content, post.country, post.date_of_visit, post.image_url, id];
    db.run(sql, params, function (err) {
      callback(err, this?.changes);
    });
  },

  deletePost: (id, callback) => {
    const sql = `DELETE FROM blog_posts WHERE id = ?`;
    db.run(sql, [id], function (err) {
      callback(err, this?.changes);
    });
  }
};
