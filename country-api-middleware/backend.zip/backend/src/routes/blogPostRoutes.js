const express = require('express');
const router = express.Router();
const blogPostService = require('../services/blogPostService');
const upload = require('../middleware/upload');

// Create a new blog post
router.post('/', upload.single('image'), (req, res) => {
  const postData = req.body;
  postData.user_id = req.user.id; // Assuming user ID is available in req.user
  if (req.file) {
    postData.image_url = `/uploads/${req.file.filename}`;
  }
  blogPostService.createPost(postData, (err, postId) => {
    if (err) {
      res.status(500).json({ error: 'Failed to create post' });
    } else {
      res.status(201).json({ message: 'Post created', postId });
    }
  });
});

// Get all blog posts
router.get('/', (req, res) => {
  blogPostService.getAllPosts((err, posts) => {
    if (err) {
      res.status(500).json({ error: 'Failed to retrieve posts' });
    } else {
      res.status(200).json(posts);
    }
  });
});

// Get a single blog post by ID
router.get('/:id', (req, res) => {
  const postId = req.params.id;
  blogPostService.getPostById(postId, (err, post) => {
    if (err) {
      res.status(500).json({ error: 'Failed to retrieve post' });
    } else if (!post) {
      res.status(404).json({ error: 'Post not found' });
    } else {
      res.status(200).json(post);
    }
  });
});

// Update a blog post
router.put('/:id', upload.single('image'), (req, res) => {
  const postId = req.params.id;
  const postData = req.body;
  if (req.file) {
    postData.image_url = `/uploads/${req.file.filename}`;
  }
  blogPostService.updatePost(postId, postData, (err, changes) => {
    if (err) {
      res.status(500).json({ error: 'Failed to update post' });
    } else if (changes === 0) {
      res.status(404).json({ error: 'Post not found' });
    } else {
      res.status(200).json({ message: 'Post updated' });
    }
  });
});

// Delete a blog post
router.delete('/:id', (req, res) => {
  const postId = req.params.id;
  blogPostService.deletePost(postId, (err, changes) => {
    if (err) {
      res.status(500).json({ error: 'Failed to delete post' });
    } else if (changes === 0) {
      res.status(404).json({ error: 'Post not found' });
    } else {
      res.status(200).json({ message: 'Post deleted' });
    }
  });
});

module.exports = router;
